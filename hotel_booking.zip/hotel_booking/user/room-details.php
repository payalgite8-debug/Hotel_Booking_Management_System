<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$room_id = $_GET['id'];

// 🔥 Room Fetch
$sql = "SELECT rooms.*, room_types.type_name 
        FROM rooms 
        JOIN room_types ON rooms.type_id = room_types.id 
        WHERE rooms.id = $room_id";

$result = $conn->query($sql);
$room = $result->fetch_assoc();


// 🔥 Insert Review
if(isset($_POST['submit_review'])){
    $rating = $_POST['rating'];
    $review = $_POST['review'];
    $user_id = $_SESSION['user_id'];

    $conn->query("INSERT INTO ratings (user_id, room_id, rating, review)
    VALUES ($user_id, $room_id, $rating, '$review')");

    echo "<div class='alert alert-success text-center'>Review Added!</div>";
}

// 🔥 Average Rating
$avg = $conn->query("SELECT AVG(rating) as avg_rating FROM ratings WHERE room_id=$room_id")->fetch_assoc();
?>

<?php include("../includes/header.php"); ?>

<div class="container mt-4">

    <div class="row">
        <!-- Image -->
        <div class="col-md-6">
            <img src="../assets/images/<?php echo $room['image']; ?>" class="img-fluid rounded shadow">
        </div>

        <!-- Details -->
        <div class="col-md-6">
            <h2>Room <?php echo $room['room_number']; ?></h2>

            <h4 class="text-success">₹<?php echo $room['price']; ?> / night</h4>

            <!-- ⭐ Rating Display -->
            <p>
                <?php
                $rating_value = round($avg['avg_rating']);
                for($i=1; $i<=5; $i++){
                    echo ($i <= $rating_value) ? "⭐" : "☆";
                }
                ?>
                (<?php echo round($avg['avg_rating'],1) ?? 0; ?>/5)
            </p>

            <p><strong>Type:</strong> <?php echo $room['type_name']; ?></p>

            <p>
                Spacious room with modern facilities, AC, WiFi, TV and attached bathroom.
            </p>

            <a href="book-room.php?id=<?php echo $room['id']; ?>" class="btn btn-success">
                Book Now
            </a>
        </div>
    </div>

    <!-- ⭐ Review Form -->
    <hr>

    <h4>Give Rating</h4>

    <form method="POST" class="mb-4">
        <select name="rating" class="form-control mb-2" required>
            <option value="">Select Rating</option>
            <option value="5">⭐⭐⭐⭐⭐</option>
            <option value="4">⭐⭐⭐⭐</option>
            <option value="3">⭐⭐⭐</option>
            <option value="2">⭐⭐</option>
            <option value="1">⭐</option>
        </select>

        <textarea name="review" class="form-control mb-2" placeholder="Write your review..."></textarea>

        <button name="submit_review" class="btn btn-warning">Submit Review</button>
    </form>

    <!-- 💬 Reviews List -->
    <h4>User Reviews</h4>

    <?php
    $reviews = $conn->query("SELECT r.*, u.name 
    FROM ratings r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.room_id=$room_id ORDER BY r.id DESC");

    if($reviews->num_rows > 0){
        while($row = $reviews->fetch_assoc()){
    ?>
        <div class="card mb-3 shadow-sm">
            <div class="card-body">
                <strong><?php echo $row['name']; ?></strong>

                <p>
                    <?php
                    for($i=1; $i<=5; $i++){
                        echo ($i <= $row['rating']) ? "⭐" : "☆";
                    }
                    ?>
                </p>

                <p><?php echo $row['review']; ?></p>
            </div>
        </div>
    <?php 
        }
    } else {
        echo "<p>No reviews yet.</p>";
    }
    ?>

</div>

<?php include("../includes/footer.php"); ?>