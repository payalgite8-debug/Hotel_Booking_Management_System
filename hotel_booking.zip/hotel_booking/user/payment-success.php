<?php
session_start();
include("../config/db.php");

// 🔥 Check payment id
if(!isset($_GET['payment_id'])){
    echo "Payment Failed!";
    exit();
}

// 🔥 Check session data
if(!isset($_SESSION['booking_data'])){
    echo "Session expired! Try again.";
    exit();
}

$data = $_SESSION['booking_data'];
$user_id = $_SESSION['user_id'];
$payment_id = $_GET['payment_id'];

// ✅ Insert booking
$sql = "INSERT INTO bookings 
(user_id, room_id, check_in, check_out, total_price, adults, children, mobile, status)
VALUES 
($user_id, {$data['room_id']}, '{$data['check_in']}', '{$data['check_out']}', {$data['total']}, {$data['adults']}, {$data['children']}, '{$data['mobile']}', 'confirmed')";

if($conn->query($sql)){

    $booking_id = $conn->insert_id;

    // ✅ Insert payment (with Razorpay ID)
    $conn->query("INSERT INTO payments 
    (booking_id, amount, payment_method, payment_status)
    VALUES 
    ($booking_id, {$data['total']}, 'online', 'paid')");

    // 🧹 Clear session
    unset($_SESSION['booking_data']);

    echo "<div class='alert alert-success'>
            Payment Successful! <br>
            Payment ID: $payment_id <br>
            Booking Confirmed!
          </div>";

} else {
    echo "Error: " . $conn->error;
}
?>
<?php include("../includes/footer.php"); ?>