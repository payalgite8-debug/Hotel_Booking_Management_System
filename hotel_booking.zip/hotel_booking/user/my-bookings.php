<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$bookings = $conn->query("
    SELECT bookings.*, rooms.room_number 
    FROM bookings
    JOIN rooms ON bookings.room_id = rooms.id
    WHERE bookings.user_id = $user_id
");
?>

<?php include("../includes/header.php"); ?>

<div class="container mt-4">
    <h2>My Bookings</h2>

    <table class="table table-bordered">
        <tr>
            <th>Room</th>
            <th>Check-in</th>
            <th>Check-out</th>
            <th>Total</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php while($b = $bookings->fetch_assoc()): ?>
        <tr>
            <td><?php echo $b['room_number']; ?></td>
            <td><?php echo $b['check_in']; ?></td>
            <td><?php echo $b['check_out']; ?></td>
            <td>₹<?php echo $b['total_price']; ?></td>
            <td><?php echo $b['status']; ?></td>
            <td>
                <?php if($b['status'] == 'confirmed'): ?>
                    <a href="cancel-booking.php?id=<?php echo $b['id']; ?>" class="btn btn-danger btn-sm">
                        Cancel
                    </a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
<?php include("../includes/footer.php"); ?>