<?php session_start(); ?>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<button id="payBtn" class="btn btn-success">Pay Now</button>

<script>
var options = {
    "key": "rzp_test_RnvvUIxBSCORXY",
    "amount": "<?php echo $_SESSION['booking_data']['total'] * 100; ?>",
    "currency": "INR",
    "name": "Dreamy Hotel",
    "description": "Room Booking Payment",

    "handler": function (response){
        window.location.href = "payment-success.php?payment_id=" + response.razorpay_payment_id;
    }
};

var rzp = new Razorpay(options);

document.getElementById('payBtn').onclick = function(e){
    rzp.open();
    e.preventDefault();
}
</script>