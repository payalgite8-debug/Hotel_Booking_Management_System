<?php 
session_start();
include("../config/db.php");

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$room_id = $_GET['id'];

if(isset($_POST['book'])){
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];
    $user_id = $_SESSION['user_id'];
    $adults = $_POST['adults'];
    $children = $_POST['children'];
    $mobile = $_POST['mobile'];
    $payment_method = $_POST['payment_method'];

    // 🔥 Coupon logic (STEP 4)
    $coupon_code = $_POST['coupon'];
    $discount = 0;

    if(!empty($coupon_code)){
        $coupon = $conn->query("SELECT * FROM coupons 
        WHERE code='$coupon_code' AND status='active'");

        if($coupon->num_rows > 0){
            $data_coupon = $coupon->fetch_assoc();
            $discount = $data_coupon['discount'];
        } else {
            echo "<div class='alert alert-danger'>Invalid Coupon Code!</div>";
        }
    }

    // 🔥 Availability Check
    $check = "SELECT * FROM bookings 
              WHERE room_id = $room_id 
              AND (check_in <= '$check_out' AND check_out >= '$check_in')
              AND status != 'cancelled'";

    $result = $conn->query($check);

    if($result->num_rows > 0){
        echo "<div class='alert alert-danger'>Room already booked for selected dates!</div>";
    } else {

        // 🔥 Price fetch
        $room = $conn->query("SELECT price FROM rooms WHERE id=$room_id")->fetch_assoc();
        $price = $room['price'];

        // 🔥 Days calculation
        $days = (strtotime($check_out) - strtotime($check_in)) / (60*60*24);

        if($days <= 0){
            echo "<div class='alert alert-danger'>Invalid date selection!</div>";
            exit();
        }

        $total = $days * $price;

        // 🔥 STEP 5: Apply Discount
        if($discount > 0){
            $discount_amount = ($total * $discount) / 100;
            $total = $total - $discount_amount;
        }

        // 🔥 PAYMENT LOGIC
        if($payment_method == "online"){

            $_SESSION['booking_data'] = [
                'user_id' => $user_id,
                'room_id' => $room_id,
                'check_in' => $check_in,
                'check_out' => $check_out,
                'total' => $total,
                'adults' => $adults,
                'children' => $children,
                'mobile' => $mobile,
                'discount' => $discount
            ];

            header("Location: payment.php");
            exit();

        } else {

            // 💵 CASH BOOKING
            $sql = "INSERT INTO bookings 
            (user_id, room_id, check_in, check_out, total_price, adults, children, mobile, status, discount)
            VALUES 
            ($user_id, $room_id, '$check_in', '$check_out', $total, $adults, $children, '$mobile', 'confirmed', $discount)";

            if($conn->query($sql)){
                echo "<div class='alert alert-success'>
                        Booking Successful (Cash Payment) <br>
                        Final Price: ₹$total
                      </div>";
            }
        }
    }
}
?>

<?php include("../includes/header.php"); ?>

<div class="container mt-5">
    <h2>Book Room</h2>

    <form method="POST">

        <label>Check-in</label>
        <input type="date" name="check_in" min="<?php echo date('Y-m-d'); ?>" class="form-control mb-3" required>

        <label>Check-out</label>
        <input type="date" name="check_out" class="form-control mb-3" required>

        <label>Adults</label>
        <input type="number" name="adults" class="form-control mb-3" required>

        <label>Children</label>
        <input type="number" name="children" class="form-control mb-3" required>

        <label>Mobile Number</label>
        <input type="text" name="mobile" class="form-control mb-3" required>

        <label>Apply Coupon</label>
        <input type="text" name="coupon" class="form-control mb-3" placeholder="Enter Coupon Code">

        <label>Select Payment Method</label>
        <select name="payment_method" class="form-control mb-3" required>
            <option value="">Select</option>
            <option value="cash">Cash on Check-in</option>
            <option value="online">Pay Online</option>
        </select>

        <button name="book" class="btn btn-success">Confirm Booking</button>
    </form>

    <!-- 🎉 Coupon Success Message -->
    <?php if(isset($discount) && $discount > 0){ ?>
        <div class="alert alert-success mt-3">
            Coupon Applied! <?php echo $discount; ?>% OFF 🎉
        </div>
    <?php } ?>

</div>

<?php include("../includes/footer.php"); ?>