
<?php include("../config/db.php"); ?>
<?php include("../includes/header.php"); ?>

<div class="container mt-4">
    <h2>Available Rooms</h2>
    <div class="row">

    <?php
    $rooms = $conn->query("SELECT * FROM rooms");

    while($row = $rooms->fetch_assoc()):
    ?>

        <div class="col-md-4">
            <div class="card mb-3">
                <img src="../assets/images/<?php echo $row['image']; ?>" class="card-img-top">
                <div class="card-body">
                    <h5>Room <?php echo $row['room_number']; ?></h5>
                    <p>Price: ₹<?php echo $row['price']; ?></p>

                  <?php if(isset($_SESSION['user_id'])): ?>
    <a href="room-details.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">
        View Details
    </a>
<?php else: ?>
    <a href="../login.php" class="btn btn-warning">
        View Details
    </a>
<?php endif; ?>

                </div>
            </div>
        </div>

    <?php endwhile; ?>

    </div>
</div>
<?php include("../includes/footer.php"); ?>