<?php
session_start();
include("../config/db.php");

$id = $_GET['id'];

if(isset($_POST['update'])){
    $price = $_POST['price'];
    $status = $_POST['status'];

    $conn->query("UPDATE rooms SET price='$price', status='$status' WHERE id=$id");
    header("Location: dashboard.php");
}

$room = $conn->query("SELECT * FROM rooms WHERE id=$id")->fetch_assoc();
?>

<form method="POST">
    <input type="number" name="price" value="<?php echo $room['price']; ?>" class="form-control mb-2">

    <select name="status" class="form-control mb-2">
        <option value="available">Available</option>
        <option value="booked">Not Available</option>
    </select>

    <button name="update" class="btn btn-success">Update</button>
</form>
<?php include("../includes/footer.php"); ?>