<?php
include("../config/db.php");

$id = $_GET['id'];

$conn->query("DELETE FROM rooms WHERE id=$id");

header("Location: dashboard.php");
?>
<?php include("../includes/footer.php"); ?>