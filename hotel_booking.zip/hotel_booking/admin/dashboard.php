<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit();
}

// 🔥 ANALYTICS
$totalBookings = $conn->query("SELECT COUNT(*) as total FROM bookings")->fetch_assoc()['total'];

$totalRevenue = $conn->query("SELECT SUM(total_price) as total FROM bookings")->fetch_assoc()['total'];

$mostBooked = $conn->query("
SELECT rooms.room_number, COUNT(bookings.id) as total 
FROM bookings 
JOIN rooms ON bookings.room_id = rooms.id 
GROUP BY room_id 
ORDER BY total DESC LIMIT 1
")->fetch_assoc();

$topRatedOne = $conn->query("
SELECT rooms.room_number, AVG(ratings.rating) as rating 
FROM ratings 
JOIN rooms ON ratings.room_id = rooms.id 
GROUP BY room_id 
ORDER BY rating DESC LIMIT 1
")->fetch_assoc();

// 🔥 DATA
$rooms = $conn->query("SELECT * FROM rooms");

$bookings = $conn->query("
SELECT bookings.*, users.name, rooms.room_number, payments.payment_status 
FROM bookings
JOIN users ON bookings.user_id = users.id
JOIN rooms ON bookings.room_id = rooms.id
LEFT JOIN payments ON bookings.id = payments.booking_id
");
?>

<?php include("../includes/header.php"); ?>

<div class="container mt-4">

<!-- 🔥 ANALYTICS CARDS -->
<div class="row text-center mb-4">

    <div class="col-md-3 mb-3">
        <div class="card shadow bg-primary text-white p-3">
            <h4><?php echo $totalBookings; ?></h4>
            <p>Total Bookings</p>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow bg-success text-white p-3">
            <h4>₹<?php echo $totalRevenue ?? 0; ?></h4>
            <p>Total Revenue</p>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow bg-warning p-3">
            <h4><?php echo $mostBooked['room_number'] ?? 'N/A'; ?></h4>
            <p>Most Booked Room</p>
        </div>
    </div>

    <div class="col-md-3 mb-3">
        <div class="card shadow bg-dark text-white p-3">
            <h4><?php echo round($topRatedOne['rating'] ?? 0,1); ?> ⭐</h4>
            <p>Top Rated Room</p>
        </div>
    </div>

</div>

<!-- ➕ ADD ROOM -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Admin Dashboard</h3>
    <a href="add-room.php" class="btn btn-success">+ Add Room</a>
</div>

<!-- ⭐ TOP RATED ROOMS -->
<h4 class="mt-4">Top Rated Rooms</h4>

<div class="row">
<?php
$topRooms = $conn->query("
SELECT rooms.*, AVG(ratings.rating) as avg_rating
FROM rooms
LEFT JOIN ratings ON rooms.id = ratings.room_id
GROUP BY rooms.id
ORDER BY avg_rating DESC
LIMIT 5
");

while($row = $topRooms->fetch_assoc()){
?>

<div class="col-md-4 mb-3">
    <div class="card shadow border-0">

        <img src="../assets/images/<?php echo $row['image']; ?>" 
             class="card-img-top" style="height:200px; object-fit:cover;">

        <div class="card-body">
            <h5>Room <?php echo $row['room_number']; ?></h5>
            <p class="text-success">₹<?php echo $row['price']; ?></p>

            <p>
                <?php
                $rating = round($row['avg_rating']);
                for($i=1; $i<=5; $i++){
                    echo ($i <= $rating) ? "⭐" : "☆";
                }
                ?>
                (<?php echo round($row['avg_rating'],1) ?? 0; ?>)
            </p>
        </div>
    </div>
</div>

<?php } ?>
</div>

<!-- 🛏️ ALL ROOMS -->
<h3 class="mt-4">All Rooms</h3>

<table class="table table-bordered table-hover">
<tr>
    <th>ID</th>
    <th>Room</th>
    <th>Price</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while($r = $rooms->fetch_assoc()): ?>
<tr>
    <td><?php echo $r['id']; ?></td>
    <td><?php echo $r['room_number']; ?></td>
    <td>₹<?php echo $r['price']; ?></td>
    <td>
        <?php if($r['status'] == 'available'){ ?>
            <span class="badge bg-success">Available</span>
        <?php } else { ?>
            <span class="badge bg-danger">Not Available</span>
        <?php } ?>
    </td>
    <td>
        <a href="edit-room.php?id=<?php echo $r['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
        <a href="delete-room.php?id=<?php echo $r['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
    </td>
</tr>
<?php endwhile; ?>

</table>

<hr>

<!-- 📦 BOOKINGS -->
<h3>All Bookings</h3>

<table class="table table-striped table-hover">
<tr>
    <th>User</th>
    <th>Room</th>
    <th>Check-in</th>
    <th>Check-out</th>
    <th>Adults</th>
    <th>Children</th>
    <th>Mobile</th>
    <th>Payment</th>
</tr>

<?php while($b = $bookings->fetch_assoc()): ?>
<tr>
    <td><?php echo $b['name']; ?></td>
    <td><?php echo $b['room_number']; ?></td>
    <td><?php echo $b['check_in']; ?></td>
    <td><?php echo $b['check_out']; ?></td>
    <td><?php echo $b['adults']; ?></td>
    <td><?php echo $b['children']; ?></td>
    <td><?php echo $b['mobile']; ?></td>
    <td>
        <?php if($b['payment_status'] == 'paid'){ ?>
            <span class="badge bg-success">Paid</span>
        <?php } else { ?>
            <span class="badge bg-warning text-dark">Cash</span>
        <?php } ?>
    </td>
</tr>
<?php endwhile; ?>

</table>

</div>

<?php include("../includes/footer.php"); ?>