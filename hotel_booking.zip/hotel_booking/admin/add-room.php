<?php
session_start();
include("../config/db.php");

// 🔐 Admin check
if($_SESSION['role'] != 'admin'){
    echo "Access Denied!";
    exit();
}

if(isset($_POST['add_room'])){
    $room_number = $_POST['room_number'];
    $type_id = $_POST['type_id'];
    $price = $_POST['price'];

    // 📸 Image Upload
    $image = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    $path = "../assets/images/" . $image;
    move_uploaded_file($tmp, $path);

    // Insert query
    $sql = "INSERT INTO rooms (room_number, type_id, price, image) 
            VALUES ('$room_number', '$type_id', '$price', '$image')";

    if($conn->query($sql)){
        echo "<div class='alert alert-success'>Room Added Successfully!</div>";
    }
}
?>

<?php include("../includes/header.php"); ?>

<div class="container mt-5">
    <h2>Add Room</h2>

    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="room_number" class="form-control mb-3" placeholder="Room Number" required>

        <select name="type_id" class="form-control mb-3" required>
            <option value="">Select Room Type</option>

            <?php
            $types = $conn->query("SELECT * FROM room_types");
            while($t = $types->fetch_assoc()):
            ?>
                <option value="<?php echo $t['id']; ?>">
                    <?php echo $t['type_name']; ?>
                </option>
            <?php endwhile; ?>

        </select>

        <input type="number" name="price" class="form-control mb-3" placeholder="Price" required>

        <input type="file" name="image" class="form-control mb-3" required>

        <button name="add_room" class="btn btn-primary">Add Room</button>
    </form>
</div>
<?php include("../includes/footer.php"); ?>