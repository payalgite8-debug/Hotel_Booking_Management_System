<?php
session_start();
include("config/db.php");

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        $user = $result->fetch_assoc();

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        // 🔥 Role-based redirect
        if($user['role'] == 'admin'){
            header("Location: admin/dashboard.php");
        } else {
            header("Location: user/index.php");
        }

    } else {
        echo "Invalid Credentials!";
    }
}
?>

<?php include("includes/header.php"); ?>

<div class="container mt-5">
    <h2>Login</h2>
    <form method="POST">
        <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
        <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
        <button name="login" class="btn btn-success">Login</button>
    </form>
</div>