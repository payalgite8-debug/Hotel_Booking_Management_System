<?php include("config/db.php"); ?>

<?php
if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $sql = "INSERT INTO users (name,email,password) VALUES ('$name','$email','$password')";
    $conn->query($sql);

    echo "Registered Successfully!";
}
?>

<?php include("includes/header.php"); ?>

<div class="container mt-5">
    <h2>Register</h2>
    <form method="POST">
        <input type="text" name="name" class="form-control mb-2" placeholder="Name" required>
        <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
        <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
        <button name="register" class="btn btn-primary">Register</button>
    </form>
</div>