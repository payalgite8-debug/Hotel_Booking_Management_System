<footer class="bg-dark text-white text-center p-3 mt-5">
    <p class="mb-0">© <?php echo date("Y"); ?> Hotel Booking System | All Rights Reserved</p>
</footer>

</body>
</html>