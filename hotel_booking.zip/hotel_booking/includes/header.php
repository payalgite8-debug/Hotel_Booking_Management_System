<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hotel Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/hotel_booking/assets/css/style.css">
   
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="/hotel_booking/user/index.php">Dreamy 5 Star Hotel⭐</a>

        <div>
            <?php if(isset($_SESSION['user_id'])): ?>
                <span class="text-white me-3">
                    Welcome, <?php echo $_SESSION['user_name']; ?>
                </span>
                <a href="/hotel_booking/logout.php" class="btn btn-danger btn-sm">Logout</a>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'user'){ ?>
    <a href="../user/my-bookings.php" class="btn btn-info">My Bookings</a>
<?php } ?>
            <?php else: ?>
                <a href="/hotel_booking/login.php" class="btn btn-success btn-sm">Login</a>
                <a href="/hotel_booking/register.php" class="btn btn-primary btn-sm">Register</a>
              
            <?php endif; ?>
        </div>
    </div>
</nav>